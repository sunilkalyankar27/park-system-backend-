package com.park_system.controller;

import com.park_system.dto.ParkingRequest;
import com.park_system.entity.ParkingSession;
import com.park_system.service.ParkingService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parking")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5173")
public class ParkingController {

    private final ParkingService service;

    // ENTRY
    @PostMapping("/entry")
    public ParkingSession entry(@RequestBody ParkingRequest request){
        return service.allocate(
                request.getName(),
                request.getVehicle(),
                request.getType(),
                request.getStorey()
        );
    }

    //Exit
    @PostMapping("/exit/{id}")
    public double exit(@PathVariable Long id) {
        return service.exit(id);
    }

    @GetMapping("/active")
    public List<ParkingSession> getActiveSessions(){
        return service.getActiveSessions();
    }
}
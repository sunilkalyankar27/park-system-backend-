package com.park_system.controller;

import com.park_system.dto.PaymentResponse;
import com.park_system.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:5173")
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping("/pay")
    public PaymentResponse pay(
            @RequestParam Long sessionId,
            @RequestParam String method) {

        return paymentService.makePayment(sessionId, method);
    }
}
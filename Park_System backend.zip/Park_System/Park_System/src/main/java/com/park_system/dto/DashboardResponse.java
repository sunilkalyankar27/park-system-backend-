package com.park_system.dto;


import lombok.Data;

@Data
public class DashboardResponse {

    private long totalVehicles;
    private long availableSlots;
    private double totalRevenue;
    private long activeSessions;
}

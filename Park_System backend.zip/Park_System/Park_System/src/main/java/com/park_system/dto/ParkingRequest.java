package com.park_system.dto;

import lombok.Data;

@Data
public class ParkingRequest {

    private String name;
    private String vehicle;
    private String type;     // 2W / 4W
    private Integer storey;  // optional
}
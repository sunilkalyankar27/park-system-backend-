package com.park_system.dto;

import lombok.Data;

@Data
public class PaymentResponse {

    private double amount;
    private long minutes;
    private String vehicle;
}
package com.park_system.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "parking_lots")
@Data
public class ParkingLot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String location;
    private Integer totalStoreys;
}
package com.park_system.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name = "parking_sessions")
@Data
public class ParkingSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User user;

    @ManyToOne
    private ParkingSlot slot;

    private String vehicleType; // 2W / 4W

    private LocalDateTime entryTime;
    private LocalDateTime exitTime;

    private String status;   // ACTIVE / COMPLETED

    @PrePersist
    public void prePersist() {
        entryTime = LocalDateTime.now();
        status = "ACTIVE";
    }
}
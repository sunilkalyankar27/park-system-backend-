package com.park_system.entity;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Table(name = "parking_slots")
@Data
public class ParkingSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer storey;
    private String slotNumber;

    private String vehicleType; // 2W / 4W

    private Boolean isOccupied = false;

    @ManyToOne
    @JoinColumn(name = "lot_id")
    private ParkingLot lot;
}
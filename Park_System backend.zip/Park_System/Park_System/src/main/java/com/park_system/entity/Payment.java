package com.park_system.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
@Data
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private ParkingSession session;

    private Double amount;

    private String method; // UPI, CARD

    private String status; // SUCCESS

    private LocalDateTime paymentTime;

    @PrePersist
    public void prePersist() {
        paymentTime = LocalDateTime.now();
    }

}
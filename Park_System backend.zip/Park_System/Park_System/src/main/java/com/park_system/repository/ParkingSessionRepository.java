package com.park_system.repository;

import com.park_system.entity.ParkingSession;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ParkingSessionRepository extends JpaRepository<ParkingSession, Long> {
    List<ParkingSession> findByStatus(String status);

    long countByStatus(String status);
}

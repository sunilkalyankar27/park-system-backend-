package com.park_system.repository;

import com.park_system.entity.ParkingSlot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ParkingSlotRepository extends JpaRepository<ParkingSlot, Long> {
    Optional<ParkingSlot> findFirstByStoreyAndVehicleTypeAndIsOccupiedFalse(Integer storey, String vehicleType);

    long countByVehicleTypeAndIsOccupiedFalse(String type);
}

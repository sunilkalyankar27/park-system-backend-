package com.park_system.service;


import com.park_system.dto.DashboardResponse;

public interface DashboardService {

    DashboardResponse getDashboard();

}

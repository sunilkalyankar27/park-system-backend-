package com.park_system.service;

import com.park_system.entity.ParkingSession;

import java.util.List;

public interface ParkingService {

    ParkingSession allocate(String name, String vehicle, String type, Integer storey);

    double exit(Long sessionId);

    List<ParkingSession> getActiveSessions();
}

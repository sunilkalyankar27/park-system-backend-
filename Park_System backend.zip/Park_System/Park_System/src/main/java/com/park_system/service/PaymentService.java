package com.park_system.service;

import com.park_system.dto.PaymentResponse;
import com.park_system.entity.Payment;

public interface PaymentService {

    PaymentResponse makePayment(Long sessionId, String method);
}

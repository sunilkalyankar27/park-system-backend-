package com.park_system.service.impl;

import com.park_system.entity.ParkingSession;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;

@Service
public class BillingService {

    public double calculateAmount(ParkingSession session) {

        long hours = Duration
                .between(session.getEntryTime(), LocalDateTime.now())
                .toHours() + 1;

        double rate;

        if ("4W".equalsIgnoreCase(session.getVehicleType())) {
            rate = 30;
        } else {
            rate = 10;
        }

        return hours * rate;
    }
}
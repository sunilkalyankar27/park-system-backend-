package com.park_system.service.impl;

import com.park_system.dto.DashboardResponse;
import com.park_system.repository.*;
import com.park_system.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final ParkingSessionRepository sessionRepo;
    private final ParkingSlotRepository slotRepo;
    private final PaymentRepository paymentRepo;

    @Override
    public DashboardResponse getDashboard() {

        DashboardResponse res = new DashboardResponse();

        res.setTotalVehicles(sessionRepo.count());

        res.setActiveSessions(
                sessionRepo.countByStatus("ACTIVE")
        );

        res.setAvailableSlots(
                slotRepo.countByVehicleTypeAndIsOccupiedFalse("4W")
        );

        res.setTotalRevenue(
                paymentRepo.getTotalRevenue()
        );

        return res;
    }
}

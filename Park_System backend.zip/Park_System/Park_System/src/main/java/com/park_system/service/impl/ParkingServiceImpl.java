package com.park_system.service.impl;

import com.park_system.entity.*;
import com.park_system.repository.*;
import com.park_system.service.ParkingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ParkingServiceImpl implements ParkingService {

    private final ParkingSlotRepository slotRepo;
    private final ParkingSessionRepository sessionRepo;
    private final UserRepository userRepo;

    // 🚗 ENTRY
    @Override
    public ParkingSession allocate(String name, String vehicle, String type, Integer preferredStorey) {

        // 1. Find or create user
        User user = userRepo.findByVehicleNumber(vehicle)
                .orElseGet(() -> {
                    User u = new User();
                    u.setName(name);
                    u.setVehicleNumber(vehicle);
                    return userRepo.save(u);
                });

        // 🚲 2W → storey 1 unlimited
        if ("2W".equalsIgnoreCase(type)) {

            ParkingSession session = new ParkingSession();
            session.setUser(user);
            session.setVehicleType("2W");

            return sessionRepo.save(session);
        }

        // 🚗 4W logic
        ParkingSlot slot = null;

        // 🔹 Try preferred storey FIRST
        if (preferredStorey != null) {
            slot = slotRepo
                    .findFirstByStoreyAndVehicleTypeAndIsOccupiedFalse(preferredStorey, "4W")
                    .orElse(null);
        }

        // 🔹 Fallback → check other storeys
        if (slot == null) {
            List<Integer> storeys = List.of(2, 3);

            for (Integer s : storeys) {
                slot = slotRepo
                        .findFirstByStoreyAndVehicleTypeAndIsOccupiedFalse(s, "4W")
                        .orElse(null);

                if (slot != null) break;
            }
        }

        // ❌ No slots available
        if (slot == null) {
            throw new RuntimeException("Parking Full for Cars");
        }

        // ✅ Mark slot occupied
        slot.setIsOccupied(true);
        slotRepo.save(slot);

        // ✅ Create session
        ParkingSession session = new ParkingSession();
        session.setUser(user);
        session.setSlot(slot);
        session.setVehicleType("4W");

        return sessionRepo.save(session);
    }

    // 🚪 EXIT + BILLING
    @Override
    public double exit(Long sessionId) {

        ParkingSession session = sessionRepo.findById(sessionId)
                .orElseThrow(() -> new RuntimeException("Invalid session"));

        session.setExitTime(LocalDateTime.now());
        session.setStatus("COMPLETED");



        // 💰 Billing
        long hours = Duration
                .between(session.getEntryTime(), session.getExitTime())
                .toHours() + 1;

        double rate;

        if ("4W".equalsIgnoreCase(session.getVehicleType())) {
            rate = 30;
        } else {
            rate = 10;
        }

        double amount = hours * rate;

        // 🅿️ Free slot (only for cars)
        if (session.getSlot() != null) {
            ParkingSlot slot = session.getSlot();
            slot.setIsOccupied(false);
            slotRepo.save(slot);
        }

        sessionRepo.save(session);

        return amount;
    }

    @Override
    public List<ParkingSession> getActiveSessions(){
        return sessionRepo.findByStatus("ACTIVE");
    }
}
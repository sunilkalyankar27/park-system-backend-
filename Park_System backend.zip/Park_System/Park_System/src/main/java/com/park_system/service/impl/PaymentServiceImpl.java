package com.park_system.service.impl;

import com.park_system.dto.PaymentResponse;
import com.park_system.entity.*;
import com.park_system.repository.*;
import com.park_system.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final ParkingSessionRepository sessionRepo;
    private final ParkingSlotRepository slotRepo;

    @Override   // 🔥 ADD HERE
    public PaymentResponse makePayment(Long sessionId, String method) {

        ParkingSession session = sessionRepo.findById(sessionId)
                .orElseThrow(() -> new RuntimeException("Session not found"));

        long minutes = Duration
                .between(session.getEntryTime(), LocalDateTime.now())
                .toMinutes();

        long hours = minutes / 60 + 1;

        double rate = session.getVehicleType().equals("4W") ? 30 : 10;
        double amount = hours * rate;

        session.setExitTime(LocalDateTime.now());
        session.setStatus("COMPLETED");

        if (session.getSlot() != null) {
            ParkingSlot slot = session.getSlot();
            slot.setIsOccupied(false);
            slotRepo.save(slot);
        }

        sessionRepo.save(session);

        PaymentResponse res = new PaymentResponse();
        res.setAmount(amount);
        res.setMinutes(minutes);
        res.setVehicle(session.getUser().getVehicleNumber());

        return res;
    }
}